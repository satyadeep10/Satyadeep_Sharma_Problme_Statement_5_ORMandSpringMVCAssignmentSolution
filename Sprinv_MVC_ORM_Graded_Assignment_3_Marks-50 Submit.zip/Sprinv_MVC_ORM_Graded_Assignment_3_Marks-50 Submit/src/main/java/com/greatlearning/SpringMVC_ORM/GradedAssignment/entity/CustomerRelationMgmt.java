package com.greatlearning.SpringMVC_ORM.GradedAssignment.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;
import javax.persistence.Id;

@Entity
@Table(name="Customer_Relation_Management")
public class CustomerRelationMgmt {
	
	@Id
	@Column(name= "id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int customerid;
	@Column(name="FirstName")
	private String firstName;
	@Column(name="LastName")
	private String lastName;
	@Column(name="emailid")
	private String emailid;
	
	
	public CustomerRelationMgmt()
	{
		super();	
	}
	
	
	public CustomerRelationMgmt(String firstName, String lastName, String emailid) {
		super();
		
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailid = emailid;
	}
	
	public int getCustomerid() {
		return customerid;
	}
	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstname) {
		firstName = firstname;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastname) {
		lastName = lastname;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	
	@Override
	public String toString() {
		return "CustomerRelationMgmt [customerid=" + customerid + ", FirstName=" + firstName + ", LastName=" + lastName
				+ ", emailid=" + emailid + "]";

	}

	
}
