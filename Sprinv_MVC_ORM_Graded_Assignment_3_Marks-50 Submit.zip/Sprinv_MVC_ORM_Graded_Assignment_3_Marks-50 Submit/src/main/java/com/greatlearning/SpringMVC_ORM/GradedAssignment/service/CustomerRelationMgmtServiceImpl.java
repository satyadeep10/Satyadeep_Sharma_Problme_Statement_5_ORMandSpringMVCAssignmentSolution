package com.greatlearning.SpringMVC_ORM.GradedAssignment.service;

import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.greatlearning.SpringMVC_ORM.GradedAssignment.entity.CustomerRelationMgmt;

@Repository
public class CustomerRelationMgmtServiceImpl implements CustomerRelationMgmtService {

	private SessionFactory sessionfactory;
	private Session session;

	@Autowired

	public CustomerRelationMgmtServiceImpl(SessionFactory sessionfactory) {
		super();
		this.sessionfactory = sessionfactory;

		try {
			this.session = this.sessionfactory.getCurrentSession();
		}

		catch (HibernateException exp) {

			this.session = this.sessionfactory.openSession();
			System.out.println("Exception is :" + exp);
		}
	}

	@Override
	public List<CustomerRelationMgmt> findAll() {
		List<CustomerRelationMgmt> customers = this.session.createQuery("From CustomerRelationMgmt").list();
		return customers;
	}

	@Override
	public CustomerRelationMgmt findbyId(int customerid) {
		CustomerRelationMgmt cust = this.session.get(CustomerRelationMgmt.class, customerid);
		return cust;
	}

	@Override
	@Transactional
	public void save(CustomerRelationMgmt customerRelationMgmt) {
		Transaction tx=this.session.beginTransaction();
		this.session.saveOrUpdate(customerRelationMgmt);
		tx.commit();

	}

	@Override
	@Transactional
	public void delete(int customerid) {
		CustomerRelationMgmt customerRelationMgmt =findbyId(customerid);
		Transaction tx=this.session.beginTransaction();
		this.session.delete(customerRelationMgmt);
		tx.commit();
		

	}

}
