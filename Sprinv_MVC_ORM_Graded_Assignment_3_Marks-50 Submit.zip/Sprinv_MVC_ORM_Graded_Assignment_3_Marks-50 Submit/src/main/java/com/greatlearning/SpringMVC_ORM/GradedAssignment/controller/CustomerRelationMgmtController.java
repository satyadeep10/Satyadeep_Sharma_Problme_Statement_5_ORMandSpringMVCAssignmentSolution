package com.greatlearning.SpringMVC_ORM.GradedAssignment.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.greatlearning.SpringMVC_ORM.GradedAssignment.entity.CustomerRelationMgmt;
import com.greatlearning.SpringMVC_ORM.GradedAssignment.service.CustomerRelationMgmtService;

@Controller
@RequestMapping("/customer")
public class CustomerRelationMgmtController {

	@Autowired
	private CustomerRelationMgmtService customerRelationMgmtService;

	@GetMapping("/list")
	public String listOfCustomers(Model theModel) {
		List<CustomerRelationMgmt> customerslist = customerRelationMgmtService.findAll();
		theModel.addAttribute("customers", customerslist);
		return "list-CRM";

	}

	@GetMapping("/showFormForAdd")
	public String addCustomer(Model theModel) {
		CustomerRelationMgmt customer = new CustomerRelationMgmt();
		theModel.addAttribute("customers", customer);
		theModel.addAttribute("mode", "Add");
		return "customer-form";

	}

	@GetMapping("/showFormForUpdate")
	public String updateCustomer(@RequestParam("customerid") int customerid, Model theModel) {
		CustomerRelationMgmt customer = customerRelationMgmtService.findbyId(customerid);
		theModel.addAttribute("customers", customer);
		theModel.addAttribute("mode", "Update");
		return "customer-form";

	}

	@PostMapping("/save")
	public String saveCustomer(
			@RequestParam(value="customerid") int customerid, 
			@RequestParam(value="firstName")  String firstName,
			@RequestParam(value="lastName")   String lastName, 
			@RequestParam(value="emailid")    String emailid) {

		CustomerRelationMgmt customerRelationMgmt = null;

		if (customerid == 0) {
			customerRelationMgmt = new CustomerRelationMgmt(firstName, lastName, emailid);
		} else {
			customerRelationMgmt = customerRelationMgmtService.findbyId(customerid);
			customerRelationMgmt.setFirstName(firstName);
			customerRelationMgmt.setLastName(lastName);
			customerRelationMgmt.setEmailid(emailid);
		}
		customerRelationMgmtService.save(customerRelationMgmt);

		return "redirect:list";

	}

	@RequestMapping("/delete")
	public String deleteCustomer(@RequestParam("customerid") int customerid) {
		customerRelationMgmtService.delete(customerid);
		return "redirect:list";

	}

}
