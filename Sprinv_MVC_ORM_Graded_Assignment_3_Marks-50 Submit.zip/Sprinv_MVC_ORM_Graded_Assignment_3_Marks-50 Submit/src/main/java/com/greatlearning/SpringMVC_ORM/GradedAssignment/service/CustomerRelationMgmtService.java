package com.greatlearning.SpringMVC_ORM.GradedAssignment.service;

import java.util.List;

import com.greatlearning.SpringMVC_ORM.GradedAssignment.entity.CustomerRelationMgmt;

public interface CustomerRelationMgmtService {
	
	public List<CustomerRelationMgmt> findAll();
	
	public CustomerRelationMgmt findbyId(int customerid);
	
	public void save(CustomerRelationMgmt customerRelationMgmt);
	
	public void delete(int customerid);

}
